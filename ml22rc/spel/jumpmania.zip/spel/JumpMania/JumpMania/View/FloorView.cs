﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace JumpMania.View
{
    class FloorView
    {
        /*public void DrawFloor(Core a_core, Model.Level a_level, Camera a_camera)
        {
            for (int x = 0; x < Model.Level.WIDTH; x++)
            {
                for (int y = 0; y < Model.Level.HEIGHT; y++)
                { 
                    
                        a_core.Draw(a_core.m_assets.m_floortexture, new Vector2(x * a_camera.m_scale, Model.Level.HEIGHT * a_camera.m_scale - a_camera.camY), new Rectangle(0, 0, 1, 1), a_camera.m_scale, Color.White); 
                    
                }
            }
        }
        
             
        public void Floor1(Core a_core, Model.Level a_level, Camera a_camera)
        {
            DrawFloor(a_core, a_level, a_camera);
        }*/
    }
}
