﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace JumpMania.Model
{
    class Player 
    {
        public float m_movement = 0.0f;
        public float m_speed = 30.0f;
        bool m_ismoving = false;
        public bool m_onground = true;
        const float MAX_SPEED = 10.0f;


        public int m_hitPoints = 0;
        public Vector2 m_position;
        public Vector2 m_oldPos;
        public Vector2 m_velocity;
        public bool m_collideGround;
        
        public bool IsAlive() 
        {
            return m_hitPoints > 0;
        }

        

        public Player()
        {
            m_hitPoints = 0;
            m_position = new Vector2(14, 82);
            m_oldPos = new Vector2(0, 0);
            m_velocity = new Vector2(0, 0);
        }

        public Player(Vector2 a_pos)
        {
            m_hitPoints = 10;
            m_position = a_pos;
            m_oldPos = m_position;
        }


        public void UpdateWalkRight(GameTime theGameTime)
        {
            m_ismoving = true;
        }


        public void UpdateWalkLeft(GameTime theGameTime)
        {
            m_ismoving = true;
        }

        public void Update(GameTime theGameTime)
        {
          if (m_ismoving == true)
            {
                float elapsed = (float)theGameTime.ElapsedGameTime.TotalSeconds;
                m_velocity.X += m_speed * elapsed * m_movement;
                if (m_velocity.X >= MAX_SPEED)
                {
                    m_velocity.X = MAX_SPEED;
                }                                       
                if (m_velocity.X <= -MAX_SPEED)
                {
                    m_velocity.X = -MAX_SPEED;
                }
                m_movement = 0.0f;
            }
        }
    }
}
