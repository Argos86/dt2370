﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace JumpMania.Model
{
    class Player : View.Sprite
    {
        public SpriteEffects Effekt = SpriteEffects.None;
        const string KaraktarBild = "images/karaktar_ninjaremake2";
        public float m_speed = 0;
        float m_acceleration = 0.7f;
        bool m_isjumping = false;
        public bool m_onground = false;




        ContentManager mContentManager;

        public KeyboardState PreviousKeyboardState;


        public void LoadContent(ContentManager theContentManager)
        {
            //Här laddas det in.
            mContentManager = theContentManager;

            m_position = new Vector2(400, -91);

            base.LoadContent(theContentManager, KaraktarBild);
        }

        public void Update(GameTime theGameTime)
        {
            //Här uppdateras ninjan.
            m_position.Y += 10;

            KeyboardState NewState = Keyboard.GetState();


            if (NewState.IsKeyDown(Keys.Space) && PreviousKeyboardState.IsKeyDown(Keys.Space) == true && m_onground == true)
            {
                m_isjumping = true;
                m_speed = 25;
                m_onground = false;
            }
            if (m_isjumping == true)
            {
                m_speed = m_speed - m_acceleration;
                m_position.Y = m_position.Y - m_speed;
                if (m_onground == true)
                {
                    m_isjumping = false;
                    m_speed = 0;
                }
            }
            PreviousKeyboardState = NewState;


            if (NewState.IsKeyDown(Keys.Right))
            {
                Effekt = SpriteEffects.None;
                m_position.X += 15;
                if (m_position.X >= 1140)
                {
                    m_position.X = 1140;
                }
            }

            if (NewState.IsKeyDown(Keys.Left))
            {
                Effekt = SpriteEffects.FlipHorizontally;
                m_position.X -= 15;
                if (m_position.X <= 0)
                {
                    m_position.X = 0;
                }
            }
        }

        public override void Draw(SpriteBatch theSpriteBatch)
        {
            //Här ritas objekt ut.
            theSpriteBatch.Draw(MSpriteTexture, m_position,
            new Rectangle(0, 0, MSpriteTexture.Width, MSpriteTexture.Height),
            Color.White, 0.0f, Vector2.Zero, m_scale, Effekt, 0);
        }

    }

}
