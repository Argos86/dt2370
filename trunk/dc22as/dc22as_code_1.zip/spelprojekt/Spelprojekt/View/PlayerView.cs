﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Featherick.View
{
    class PlayerView
    {
        public void DrawSoldier(Core a_core, Vector2 a_pos)
        {
            int size = 16;
            Vector2 pos = a_pos - new Vector2(size / 2, size / 2);
            Rectangle dest = new Rectangle((int)pos.X, (int)pos.Y, size, size);
            a_core.Draw(a_core.m_assets.m_texture, dest, new Rectangle(74, 204, 36, 36), Color.Gray);
        }

       /* public void DrawPlayer(GameTime gameTime, SpriteBatch spriteBatch)
        {
            // Flip the sprite to face the way we are moving.
            if (Velocity.X > 0)
            {
                flip = SpriteEffects.FlipHorizontally;
            }
            else if (Velocity.X < 0)
            {
                flip = SpriteEffects.None;
            }
                

            // Draw that sprite.
            sprite.Draw(gameTime, spriteBatch, Position, flip);
        }*/
    }
}
