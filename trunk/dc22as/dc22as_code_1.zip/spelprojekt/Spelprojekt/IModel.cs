﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Featherick
{
    interface IModel
    {
        //void BuySoldier(Vector2 a_at);
        ///void MoveSoldier(int a_index, Vector2 a_at);
        //void MoveCivilian(int a_index, Vector2 a_at);
        //void Draw(bool a_index, Vector2 a_at);
    }
}
