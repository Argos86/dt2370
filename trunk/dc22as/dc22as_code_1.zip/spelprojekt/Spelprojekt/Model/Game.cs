﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Featherick.Model
{
    class Game : IModel
    {
        public Player m_player;
        //public int m_points = 0;
        public int m_time = 0;

        public float GetTimeSeconds(GameTime a_gameTime)
        {
            return 1.0f * (float)a_gameTime.ElapsedGameTime.TotalMilliseconds / 1000.0f;
        }

        public Featherick.IEventTarget m_view;

        public Game(Featherick.IEventTarget a_view)
        {
            m_view = a_view;
            Init();
        }

        /*public void BuySoldier(Vector2 a_at)
        {
            if (m_cash >= 25)
            {
                AddSoldier(a_at);
                m_cash -= 25;
            }
        }*/

        private void Init()
        {

            /*m_enemies = new Character[MAX_ENEMIES];
            for (int i = 0; i < MAX_ENEMIES; i++)
            {
                m_enemies[i] = new Character();
            }*/

            m_player = new Player();
            
        }

        public bool IsGameOver()
        {
            if(!m_player.IsAlive())
            {
                return true;
            }
            return false;            
        }

        /*public bool HasWon()
        {
            for (int i = 0; i < MAX_WAVES; i++)
            {
                if (m_waves[i].m_isActive == true)
                {
                    return false;
                }
            }
            for (int i = 0; i < MAX_ENEMIES; i++)
            {
                if (m_enemies[i].IsAlive() == true)
                {
                    return false;
                }
            }
            return true;
        }*/

        public void Draw(bool a_blocked, Vector2 a_at)
        {
            // a_at = Model.MathHelper.Clamp(new Vector2(0, 0), new Vector2(Map.WIDTH - 1, Map.HEIGHT - 1), a_at);
            //m_map.m_tiles[(int)a_at.X, (int)a_at.Y].m_tileType = a_blocked ? Tile.TileType.Blocked : Tile.TileType.Clear;
        }

        public bool Update(float a_gameTime)
        {
            /*
            //no civilians alive return false
            if (IsGameOver() == true || HasWon() == true)
            {
                return false;
            }

            //Check waves
            for (int i = 0; i < MAX_WAVES; i++)
            {
                if (m_waves[i].m_isActive == true)
                {
                    m_waves[i].m_timer -= a_gameTime;
                    if (m_waves[i].m_timer < 0.0f)
                    {
                        ActivateWave(ref m_waves[i]);

                    }
                    break;
                }
            }

            //Update enemies
            for (int i = 0; i < MAX_ENEMIES; i++)
            {
                UpdateEnemy(i, a_gameTime);
            }

            for (int i = 0; i < MAX_SOLDIERS; i++)
            {
                UpdateSoldier(i, a_gameTime);

            }
            */
            return true;
        }
    }
}
