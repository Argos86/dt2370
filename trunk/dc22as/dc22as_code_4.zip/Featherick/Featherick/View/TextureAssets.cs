﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace Featherick.View
{
    class TextureAssets
    {
        public Texture2D m_playerTexture;
        public Texture2D m_block16Texture;
        public Texture2D m_block64Texture;
        public Texture2D m_block48Texture;

        public void LoadContent(ContentManager a_content)
        {
            m_playerTexture = a_content.Load<Texture2D>("images/playerSprite");
            m_block16Texture = a_content.Load<Texture2D>("images/block16");
            m_block64Texture = a_content.Load<Texture2D>("images/block64");
            m_block48Texture = a_content.Load<Texture2D>("images/block48");
        }
    }
}
