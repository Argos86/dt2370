#include <Ogre.h>
#include <OIS/OIS.h>
#include "GameController.h"
#include "..\Model\Player.h"
#include "..\Model\Level.h"
#include "..\View\GameView.h"
#include "..\View\Camera.h"

GameController::GameController(Ogre::Root *a_root, Ogre::SceneManager *a_scanemgr, OIS::InputManager *a_inputmgr)
{
	m_player = new Player(a_scanemgr);
	m_camera = new CameraManager(a_scanemgr, a_root);
	m_gameView = new GameView(a_inputmgr, a_root);
	m_level = new Level(a_scanemgr);
}

void GameController::DoControll(Ogre::SceneManager *a_scenemgr, float a_timeSinceLastFrame, OIS::Keyboard *a_keyboard)
{
	m_gameView->UpdateInput();

	if (m_gameView->GetKeyEvent() != NULL){
		if ( m_gameView->GetKeyEvent()->isKeyDown( OIS::KC_E )) {
			m_level->SpawnEnemy(a_scenemgr,a_timeSinceLastFrame);
		}
		if ( m_gameView->GetKeyEvent()->isKeyDown( OIS::KC_R )) {
			m_player->ResetOrientation();
			m_camera->ResetOrientation();
		}
		if ( m_gameView->MousePressed()) {
			m_player->FireWeapon(a_scenemgr);
		}
		if ( m_gameView->GetKeyEvent()->isKeyDown( OIS::KC_A )) {
			m_player->Move( Ogre::Vector3(-0.4f,0,0), a_timeSinceLastFrame);
		}
		if ( m_gameView->GetKeyEvent()->isKeyDown( OIS::KC_D )) {
			m_player->Move( Ogre::Vector3(+0.4f,0,0), a_timeSinceLastFrame);
		}
	}


	m_level->UpdateEnemies( a_timeSinceLastFrame );
	m_player->Update( m_gameView->GetMouseMovement(), a_timeSinceLastFrame, a_scenemgr );
	m_camera->Update(  m_player->GetPosition(), m_gameView->GetMouseMovement() );	

}



GameController::~GameController()
{


}
