#ifndef Game_Controller_H_
#define Game_Controller_H_

#include <Ogre.h>
#include <OIS/OIS.h>
#include "..\Model\Player.h"
#include "..\Model\Level.h"
#include "..\View\GameView.h"
#include "..\View\Camera.h"

class GameController
{
private:
	Player *m_player ;
	CameraManager *m_camera;
	GameView *m_gameView;
	Level *m_level;


public:	
	GameController::GameController( Ogre::Root *a_root, Ogre::SceneManager *a_scanemgr, OIS::InputManager *a_inputmgr );
	void GameController::DoControll(Ogre::SceneManager *a_scanemgr, float a_timeSinceLastFrame, OIS::Keyboard *a_keyboard);
	GameController::~GameController();
};
#endif
