#ifndef Game_View_H_
#define Game_View_H_

#include <Ogre.h>
#include <OIS/OIS.h>
#include "KeyboardListener.h"

class GameView 
{
private:
	OIS::Keyboard *m_keyboard;
	OIS::Mouse *m_mouse;
	KeyboardListener *m_listener;

public:	
	GameView::GameView(OIS::InputManager *inputManager, Ogre::Root *root);
	bool GameView::MousePressed(); 

	void GameView::UpdateInput( );

	Ogre::Vector2 GameView::GetMouseMovement();
	OIS::Keyboard *GameView::GetKeyEvent();

	GameView::~GameView();
};

#endif
