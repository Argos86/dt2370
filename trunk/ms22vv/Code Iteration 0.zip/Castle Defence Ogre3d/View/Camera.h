#ifndef Camera_Manager_H_
#define Camera_Manager_H_

#include <Ogre.h>
#include <OIS/OIS.h>

class CameraManager
{
private:
	Ogre::SceneNode *m_cameraNode;
	Ogre::SceneNode *m_cameraYawNode;
	Ogre::SceneNode *m_cameraPitchNode;
	Ogre::SceneNode *m_cameraRollNode;

	Ogre::SceneNode *m_transNode;
	Ogre::Vector3 m_camPosition;
	Ogre::Quaternion m_camOrientation;
	Ogre::Viewport *m_camVp;
	Ogre::Camera *m_camera;
	Ogre::Real m_offsetX;
	Ogre::Real m_offsetY;
	Ogre::Quaternion tempQuat;



public:	
	CameraManager::CameraManager( Ogre::SceneManager *a_scenemgr, Ogre::Root *a_root );
	void CameraManager::Update( Ogre::Vector3 a_playerPosition, Ogre::Vector2 a_mousePosition );
	Ogre::Vector3 CameraManager::GetPosition();
	Ogre::Quaternion CameraManager::GetOrientation();
	void CameraManager::ResetOrientation();
	CameraManager::~CameraManager();
};
#endif
