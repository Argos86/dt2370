#include <Ogre.h>
#include <OIS/OIS.h>
#include "Camera.h"

CameraManager::CameraManager(Ogre::SceneManager *a_scenemgr, Ogre::Root *a_root)
{
	m_cameraNode = a_scenemgr->getRootSceneNode()->createChildSceneNode();
	m_cameraNode->setPosition(Ogre::Vector3(0,0,0));

	m_camera = a_scenemgr->createCamera("Camera");
	//m_camera->setPosition(Ogre::Vector3(0,10,500));
	//m_camera->lookAt(Ogre::Vector3(0,0,0));
	m_camera->setNearClipDistance(10);
	
	m_camera->setPosition(Ogre::Vector3(0,0,0));
	m_camVp = a_root->getAutoCreatedWindow()->addViewport(m_camera);	
	m_cameraNode->attachObject(m_camera);
	m_offsetX = 0;
	m_offsetY = 0;
	//m_camera->setAspectRatio(m_camVp->getActualWidth() / m_camVp->getActualHeight());
}

void CameraManager::Update(Ogre::Vector3 a_playerPosition, Ogre::Vector2 a_mousePosition)
{
	m_cameraNode->setPosition( a_playerPosition );

	m_offsetX += a_mousePosition.x;
	m_offsetY += a_mousePosition.y;
	if ( m_offsetX > 80) {	m_offsetX = 80;	}
	else if ( m_offsetX < -80) {	m_offsetX = -80; }
	else {
		m_camera->yaw(Ogre::Degree(- a_mousePosition.x));
		m_camera->pitch(Ogre::Degree(- a_mousePosition.y));
	}

	m_cameraNode->setPosition(m_cameraNode->getPosition() + m_cameraNode->getOrientation() * Ogre::Vector3(-m_offsetX * 2, +50 +m_offsetY * 2, +100));
}

Ogre::Vector3 CameraManager::GetPosition()
{
	if(m_camera) {
		return m_camera->getPosition();
	}
	else {
		return Ogre::Vector3();
	}
}

Ogre::Quaternion CameraManager::GetOrientation()
{
	if(m_camera) {
		return m_camera->getOrientation();
	}
	else {
		return Ogre::Quaternion();
	}	
}

void CameraManager::ResetOrientation()
{
	std::cout << "Camera::Quaternion = " << this->GetOrientation()  << std::endl; 
	m_camera->setOrientation(Ogre::Quaternion::IDENTITY);
	m_offsetX = 0;
	m_offsetY = 0;
}

CameraManager::~CameraManager()
{
	
}

