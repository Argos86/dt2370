#include <Ogre.h>
#include <OIS/OIS.h>
#include "GameView.h"
#include "KeyboardListener.h"


GameView::GameView(OIS::InputManager *inputManager, Ogre::Root *root)
{
	
	try
        {
            m_keyboard = static_cast<OIS::Keyboard*>(inputManager->createInputObject(OIS::OISKeyboard, false));
            m_mouse = static_cast<OIS::Mouse*>(inputManager->createInputObject(OIS::OISMouse, false));
            //mJoy = static_cast<OIS::JoyStick*>(mInputManager->createInputObject(OIS::OISJoyStick, false));
        }
        catch (const OIS::Exception &e)
        {
			throw new Ogre::Exception(42, e.eText, "Application::setupInputSystem");
        }

	m_listener = new KeyboardListener(m_keyboard);
	root->addFrameListener(m_listener);
}

void GameView::UpdateInput()
{
	m_keyboard->capture();
	m_mouse->capture();
}

Ogre::Vector2 GameView::GetMouseMovement()
{
	return Ogre::Vector2(m_mouse->getMouseState().X.rel * 0.1, m_mouse->getMouseState().Y.rel * 0.1);
}

bool GameView::MousePressed()
{
	if (m_mouse->getMouseState().buttonDown(OIS::MB_Left)) {
		return true;
	}

	else { return false;
	}
}

OIS::Keyboard *GameView::GetKeyEvent()
{
	return m_keyboard;
}

GameView::~GameView()
{
	delete m_listener;
	m_listener = NULL;
}


