#ifndef Weapon_Sight_H_
#define Weapon_Sight_H_

#include <Ogre.h>

class WeaponSight
{
private:
	Ogre::SceneNode *m_sightNode;
	Ogre::BillboardSet *m_sightBbs;

public:	
	WeaponSight::WeaponSight( Ogre::SceneNode *a_playerNode, Ogre::SceneManager *a_scenemgr );
	WeaponSight::~WeaponSight();
};
#endif
