#ifndef Projectile_H_
#define Projectile_H_

#include <Ogre.h>
#include <OIS/OIS.h>

class Projectile 
{
private:
	Ogre::SceneNode *m_projectileNode;
	Ogre::String m_uniqueName;
	Ogre::BillboardSet *m_projectileBbs;
	// TODO: SceneManager ska bort!!
	Ogre::SceneManager *m_scenemgr;
	Ogre::Real m_velocity;

public:	
	Projectile::Projectile( Ogre::Vector3 weaponPosition, Ogre::Quaternion weaponOrientation, Ogre::SceneManager *mgr, Ogre::Real m_fireId);
	void Projectile::Update( Ogre::Real timeSinceLastFrame);

	// tiden borde vara private..
	Ogre::Real m_time;
	Projectile::~Projectile();	
};
#endif
