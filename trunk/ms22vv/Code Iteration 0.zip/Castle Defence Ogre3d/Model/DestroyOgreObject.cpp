//#include <Ogre.h>
//#include "DestroyOgreObject.h" 
//
//
//DestroyOgreObject::_instance = NULL;
//
//
//DestroyOgreObject* DestroyOgreObject::GetSingleton()
//{
//	if (_instance == NULL)
//	{
//		_instance = new DestroyOgreObject;
//	}
//
//	return _instance;
//}
//
//void DestroyOgreObject::DestroyEntity()
//{
//
//}
//
//void DestroyOgreObject::AddSceneManager()
//{
//	//m_scenemgr =
//}
//
//
//
