#include <Ogre.h>
#include <OIS/OIS.h>
#include "Weapon.h"
#include "Projectile.h"
#include "WeaponSight.h"

Weapon::Weapon(Ogre::SceneNode *a_playerNode, Ogre::SceneManager *a_scenemgr)
{
	m_weaponEntity = a_scenemgr->createEntity( "WeaponEntity", "Mesh/Box02.mesh" );
	m_weaponEntity->setMaterialName("test1");
	m_weaponNode = a_playerNode->createChildSceneNode("WeaponNode", Ogre::Vector3(0,0,0));
	m_weaponNode->setScale(1.0,1.0,1.0);
	m_weaponNode->attachObject( m_weaponEntity );
	m_weaponOffsetX = 0;
	m_weaponOffsetY = 0;
	m_fireId = 0;

	// Nollar pekarna..
	for (int x = 0; x < MAX_PROJECTILES-1 ; x++)
	{
		m_fire[x] = NULL;
	}

	m_sight = new WeaponSight(m_weaponNode, a_scenemgr);
} 


void Weapon::Update( Ogre::Vector2 a_mousePosition, Ogre::Real a_timeSinceLastFrame)
{
	m_weaponNode->setPosition(Ogre::Vector3(0,+20,-10));
	m_weaponOffsetX += a_mousePosition.x;
	m_weaponOffsetY += a_mousePosition.y;

	if ( m_weaponOffsetX > 80) { m_weaponOffsetX = 80; }
	else if ( m_weaponOffsetX < -80) { m_weaponOffsetX = -80; }
	else {
		m_weaponNode->yaw(Ogre::Degree( - a_mousePosition.x));
		m_weaponNode->pitch(Ogre::Degree( - a_mousePosition.y));
	}
	float temp = 0;
	if (m_weaponOffsetX > 0) { temp -= m_weaponOffsetX;	}
	else {temp += m_weaponOffsetX; }
	m_weaponNode->setPosition( m_weaponNode->getPosition() + m_weaponNode->getOrientation() * Ogre::Vector3(0.4f * m_weaponOffsetX -10.0f, 20.0f + 0.2f * temp, 0.0f) );		
	

	for (int x = 0; x < MAX_PROJECTILES-1 ; x++)
	{
		if(m_fire[x] != NULL)
		{
			m_fire[x]->Update(a_timeSinceLastFrame);
			if (m_fire[x]->m_time > 5000)
			{
				delete m_fire[x];
				m_fire[x] = NULL;
			}
		}
	}
	if ( m_fireId == (MAX_PROJECTILES -1) )
	{
		m_fireId = 0;
	}

	//for each (Projectile *x in m_fire)	{
	//	if (x != NULL){
	//	x->Update(timeSinceLastFrame);
	//	}
	//}
}

void Weapon::Fire(Ogre::SceneManager *a_scenemgr)
{
	m_fire[m_fireId] = new Projectile( m_weaponNode->getParentSceneNode()->getPosition() + m_weaponNode->getParentSceneNode()->getOrientation() * m_weaponNode->getPosition(), m_weaponNode->getOrientation(), a_scenemgr, m_fireId);
	m_fireId += 1;

	std::cout << "Weapon position: "<< m_weaponNode->getPosition() << std::endl; 
	std::cout << "Calculated position: "<< m_weaponNode->getParentSceneNode()->getPosition() + m_weaponNode->getParentSceneNode()->getOrientation() * m_weaponNode->getPosition() << std::endl; 
}



Ogre::Vector3 Weapon::GetPosition()
{
	if (m_weaponNode) {
		return m_weaponNode->getPosition();
	}
	else {
		return Ogre::Vector3();
	}
}

Ogre::Quaternion Weapon::GetOrientation()
{
	if (m_weaponNode) {
		return m_weaponNode->getOrientation();
	}
	else {
		return Ogre::Quaternion();
	}
}

void Weapon::ResetOrientation()
{
	std::cout << "Weapon::Quaternion = " << this->GetOrientation()  << std::endl; 
	m_weaponNode->setOrientation(Ogre::Quaternion::IDENTITY);
	m_weaponOffsetX = 0;
	m_weaponOffsetY = 0;
}


Weapon::~Weapon()
{

}


