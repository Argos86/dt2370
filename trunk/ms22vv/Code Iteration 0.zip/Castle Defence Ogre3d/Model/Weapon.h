#ifndef Weapon_H_
#define Weapon_H_

#include <Ogre.h>
#include <OIS/OIS.h>
#include "Projectile.h"
#include "WeaponSight.h"

class Weapon
{
private:
	static const int MAX_PROJECTILES = 200;
	Ogre::Entity *m_weaponEntity;
	Ogre::SceneNode *m_weaponNode;
	Ogre::Real m_weaponOffsetX;
	Ogre::Real m_weaponOffsetY;
	int m_fireId;
	Projectile *m_fire[MAX_PROJECTILES];
	WeaponSight *m_sight;
	

public:	
	Weapon::Weapon( Ogre::SceneNode *a_playerNode, Ogre::SceneManager *a_scenemgr );
	void Weapon::Update( Ogre::Vector2 a_mousePosition, Ogre::Real a_timeSinceLastFrame );
	void Weapon::Fire( Ogre::SceneManager *a_scenemgr );

	Weapon::~Weapon();

	Ogre::Vector3 Weapon::GetPosition();
	Ogre::Quaternion Weapon::GetOrientation();
	void Weapon::ResetOrientation();
};
#endif
