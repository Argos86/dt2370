#ifndef Enemy_H_
#define Enemy_H_

#include <Ogre.h>

class Enemy 
{
private:
	Ogre::SceneNode *m_enemyNode;
	Ogre::Entity *m_enemyEntity;
	float m_enemyVelocity;
	Ogre::String m_uniqueName;

	Ogre::SceneManager *m_scenemgr;

public:	
	Enemy::Enemy(Ogre::SceneManager *a_scenemgr, int a_enemyId);
	void Enemy::Update( float a_timeSinceLastFrame);
	Ogre::Vector3 Enemy::GetPosition();
	Ogre::Quaternion Enemy::GetOrientation();
	Enemy::~Enemy();
};
#endif
