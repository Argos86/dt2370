#include <Ogre.h>
#include <OIS/OIS.h>
#include "Weapon.h"
#include "Projectile.h"

Projectile::Projectile(Ogre::Vector3 a_weaponPosition, Ogre::Quaternion a_weaponOrientation, Ogre::SceneManager *a_scenemgr, Ogre::Real a_fireId)
{
	std::stringstream name;
    name << "Fire" << a_fireId;
    m_uniqueName = name.str();

	//Vill inte ha instans av SceneManager h�r..
	m_scenemgr = a_scenemgr;

	// Billboard
	m_projectileBbs = m_scenemgr->createBillboardSet( m_uniqueName );
	m_projectileBbs->setDefaultDimensions(5, 5);
	m_projectileBbs->setMaterialName("Examples/Flare");
	m_projectileBbs->createBillboard(0,0,0, Ogre::ColourValue::White);	


	m_time = 0;
	m_velocity =  0.8f;

	m_projectileNode = m_scenemgr->getRootSceneNode()->createChildSceneNode( m_uniqueName, a_weaponPosition );
	m_projectileNode->setOrientation(a_weaponOrientation);
	//m_projectileNode->pitch(Ogre::Degree(+ 90));

	m_projectileNode->attachObject( m_projectileBbs );
	std::cout << "Projectile position: "<< m_projectileNode->getPosition() << std::endl; 

}

void Projectile::Update(Ogre::Real timeSinceLastFrame)
{
	m_time += timeSinceLastFrame;
	m_projectileNode->setPosition( m_projectileNode->getPosition() + m_projectileNode->getOrientation() * Ogre::Vector3(0.0f,0.0f,-1.0f * m_velocity * timeSinceLastFrame) );	
}

Projectile::~Projectile()
{
   // KILLCHILD(m_projectileNode);
	m_projectileBbs = NULL;
	m_projectileNode = NULL;
	m_scenemgr->destroyBillboardSet(m_uniqueName);
	m_scenemgr->destroySceneNode(m_uniqueName);
	//Ogre::SceneManager::destroyBillboardSet(m_uniqueName);
	//Ogre::SceneManager::get(m_uniqueName);
}