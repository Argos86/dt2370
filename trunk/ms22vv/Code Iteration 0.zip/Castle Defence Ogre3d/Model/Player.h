#ifndef Player_H_
#define Player_H_

#include <Ogre.h>
#include <OIS/OIS.h>
#include "Weapon.h"

class Player
{
private:
	Ogre::SceneNode *m_playerNode;
	Ogre::Entity *m_playerEntity;
	float m_playerVelocity;

	//Weapon
	Weapon *m_weapon;

public:	
	Player::Player(Ogre::SceneManager *a_scenemgr);
	void Player::Move(Ogre::Vector3 movementVector, float a_timeSinceLastFrame);
	void Player::Update(Ogre::Vector2 a_mousePosition, float a_timeSinceLastFrame, Ogre::SceneManager *a_scenemgr);
	Ogre::Vector3 Player::GetPosition();
	Ogre::Quaternion Player::GetOrientation();
	void Player::ResetOrientation();
	float Player::GetVelocity();

	void Player::FireWeapon(Ogre::SceneManager *a_scenemgr);
	Ogre::Vector3 Player::GetWeaponPosition();
	Ogre::Quaternion Player::GetWeaponOrientation();

	Player::~Player();
};
#endif
