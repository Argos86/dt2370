#include <Ogre.h>
#include "Level.h"
#include "Enemy.h"
#include "LightSource.h"
#include "Castle.h"

Level::Level(Ogre::SceneManager *a_scenemgr)
{
	m_castle = new Castle(a_scenemgr);
	// Belysningen, tillf�llingt
	m_light1 = new LightSource(a_scenemgr, Ogre::Vector3(-600, 100, -600), "Light1");
	m_light2 = new LightSource(a_scenemgr, Ogre::Vector3(600, 100, 600), "Light2");

	// Skyboxen, tillf�llingt
    a_scenemgr->setSkyBox(true, "Ruins");

	// Plane, tillf�llingt
	Ogre::Plane plane(Ogre::Vector3::UNIT_Y, 0);
	Ogre::MeshManager::getSingleton().createPlane("ground",
		Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane,
	   1500,1500,20,20,true,1,5,5,Ogre::Vector3::UNIT_Z);
	Ogre::Entity *entGround = a_scenemgr->createEntity("GroundEntity", "ground");
	entGround->setMaterialName("test1");
    entGround->setCastShadows(false);
	a_scenemgr->getRootSceneNode()->createChildSceneNode()->attachObject(entGround);

	for (int x = 0; x < MAX_ENEMIES-1 ; x++)
	{
		m_enemy[x] = NULL;
	}
	m_enemyId = 0;
}

void Level::SpawnEnemy( Ogre::SceneManager *a_scenemgr, float a_timeSinceLastFrame )
{
	m_enemy[m_enemyId] = new Enemy( a_scenemgr, m_enemyId);
	m_enemyId += 1;	
}

void Level::UpdateEnemies(float a_timeSinceLastFrame )
{
	for (int x = 0; x < MAX_ENEMIES -1 ; x++) {
		if(m_enemy[x] != NULL)	{

			m_enemy[x]->Update(a_timeSinceLastFrame);

			if ( m_enemy[x]->GetPosition().z > +800 ) {
				delete m_enemy[x];
				m_enemy[x] = NULL;
			}
		}
	}
	if ( m_enemyId == (MAX_ENEMIES -1) ) {
		m_enemyId = 0;
	}		
}




Level::~Level()
{

}


