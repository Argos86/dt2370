#include <Ogre.h>
#include "Castle.h"

Castle::Castle(Ogre::SceneManager *a_scenemgr)
{

	m_castleEntity = a_scenemgr->createEntity( "CastleEntity", "Mesh/Box02.mesh" );
	m_castleEntity->setMaterialName("test1");
	m_castleEntity->setCastShadows(true);

	m_castleNode = a_scenemgr->getRootSceneNode()->createChildSceneNode( "CastleNode", Ogre::Vector3(0.0f, 0.0f, +800.0f) );
	m_castleNode->setScale(100.0,4.0,4.0);
	m_castleNode->attachObject( m_castleEntity );
}

void Castle::Update( float a_timeSinceLastFrame )
{
	
}



Castle::~Castle()
{

}


