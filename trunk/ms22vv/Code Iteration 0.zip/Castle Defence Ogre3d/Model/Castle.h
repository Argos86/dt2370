#ifndef Castle_H_
#define Castle_H_

#include <Ogre.h>

class Castle 
{
private:
	Ogre::SceneNode *m_castleNode;
	Ogre::Entity *m_castleEntity;


public:	
	Castle::Castle(Ogre::SceneManager *a_scenemgr);
	void Castle::Update( float a_timeSinceLastFrame);
	Castle::~Castle();
};
#endif
