#include <Ogre.h>
#include "WeaponSight.h"

WeaponSight::WeaponSight(Ogre::SceneNode *a_weaponNode, Ogre::SceneManager *a_scenemgr)
{
	m_sightBbs = a_scenemgr->createBillboardSet( "SightBbs" );
	m_sightBbs->setDefaultDimensions(5, 5);
	m_sightBbs->setMaterialName("Examples/Flare");
	m_sightBbs->createBillboard(0,0,0, Ogre::ColourValue::Red);
	
	m_sightNode = a_weaponNode->createChildSceneNode("SightNode", Ogre::Vector3::ZERO);
	m_sightNode->attachObject( m_sightBbs );
	m_sightNode->setPosition( m_sightNode->getPosition() + m_sightNode->getOrientation() * Ogre::Vector3(0,0,-200));
} 



WeaponSight::~WeaponSight()
{
	m_sightNode = NULL;
	m_sightBbs = NULL;

	//TODO: M�ste komma p� n�got bra s�tt �n o ha SceneManager...
	//->destroyBillboardSet("SightBbs");
	//->destroySceneNode("SightNode");
}
