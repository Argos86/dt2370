#include <Ogre.h>
#include "Enemy.h"
#include "DestroyOgreObject.h"
#include <cstdlib> 

Enemy::Enemy(Ogre::SceneManager *a_scenemgr, int a_enemyId)
{
	std::stringstream name;
    name << "Enemy" << a_enemyId;
    m_uniqueName = name.str();
	m_scenemgr = a_scenemgr;

	m_enemyEntity = m_scenemgr->createEntity( m_uniqueName, "Mesh/Box02.mesh" );
	m_enemyEntity->setMaterialName("test1");
	m_enemyEntity->setCastShadows(true);

	m_enemyNode = m_scenemgr->getRootSceneNode()->createChildSceneNode( m_uniqueName, Ogre::Vector3(0.0f, 0.0f, 0.0f) );
	m_enemyNode->setScale(1.0,1.0,1.0);
	m_enemyNode->attachObject( m_enemyEntity );
	m_enemyVelocity = 0.1;

	int randomInt = rand() % 1000 - 500;
	m_enemyNode->setPosition(Ogre::Vector3(randomInt,0,0));
}

void Enemy::Update( float a_timeSinceLastFrame )
{
	m_enemyNode->setPosition( m_enemyNode->getPosition() + m_enemyNode->getOrientation() * Ogre::Vector3(0.0f,0.0f, m_enemyVelocity * a_timeSinceLastFrame) );
}

Ogre::Vector3 Enemy::GetPosition()
{
	if (m_enemyNode) {
		return m_enemyNode->getPosition();
	}
	else {
		return Ogre::Vector3();
	}
}

Ogre::Quaternion Enemy::GetOrientation()
{
	if (m_enemyNode) {
		return m_enemyNode->getOrientation();
	}
	else {
		return Ogre::Quaternion();
	}
}


Enemy::~Enemy()
{
	m_enemyEntity = NULL;
	m_enemyNode = NULL;
	//samma problem h�r..
	m_scenemgr->destroyEntity(m_uniqueName);
	m_scenemgr->destroySceneNode(m_uniqueName);	
}


