﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace CombatLand.Controller
{
    class PlayGame:ControllerBase
    {
        public bool DoControl(Model.Game a_game, float a_elapsedTime)
        {
            m_view.Draw(a_game, a_elapsedTime, scale, m_selectedCharacter );
            return true;
        }
    }
}
