﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;


namespace CombatLand.View
{
    class Core
    {
        GraphicsDeviceManager m_graphics;
        SpriteBatch m_spriteBatch;
        //public Views.Input m_input;
        //public Views.TextureAssets m_assets;
        //public Views.FontAssets m_fonts;
        //public Views.SoundAssets m_sounds;
        GraphicsDevice m_device;

        public Core(GraphicsDeviceManager a_graphics)
        {
            m_graphics = a_graphics;
            //m_input = new Input();
            //m_assets = new Views.TextureAssets();
            //m_fonts = new Views.FontAssets();
            //m_sounds = new Views.SoundAssets();
        }

        public void Draw(Texture2D a_texture, Rectangle a_dest, Rectangle a_source, Color a_color)
        {
            m_spriteBatch.Draw(a_texture, a_dest, a_source, a_color);
        }
    }
}
