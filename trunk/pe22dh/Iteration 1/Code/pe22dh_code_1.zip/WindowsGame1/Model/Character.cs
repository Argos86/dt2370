﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace CombatLand.Model
{
    class Character
    {
        public const int MAX_HP = 10;
        public const int MAX_BULLETS = 100;
        
        public int m_hitPoints;
        public Vector2 m_pos;
        public Bullet[] m_bullets;

        public bool IsAlive()
        {
            return m_hitPoints > 0;
        }

        public Character()
        {
            m_hitPoints = 10;
            m_pos = new Vector2(0.1f, 0.5f);
            m_bullets = new Bullet[MAX_BULLETS];
        }
        public void MoveRight()
        {
            m_pos.X += 0.2f;
        }
        public void MoveLeft()
        {
            m_pos.X -= 0.2f;
        }
    }
}
