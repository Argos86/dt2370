﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace CombatLand.Model
{
    class Game
    {
        public Character m_player;
        public Character[] m_enemies;
        public Level m_level;
    }
}
