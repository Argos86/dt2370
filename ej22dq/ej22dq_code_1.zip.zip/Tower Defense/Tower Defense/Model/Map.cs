﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Tower_Defense.Model
{
    class Map
    {
        public enum Direction
        {
            North,
            East,
            South,
            West
        };

        public Tile[,] m_tiles;
        public const int WIDTH = 48;
        public const int HEIGHT = 32;

        public Map()
        {
            m_tiles = new Tile[WIDTH, HEIGHT];
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    m_tiles[x, y] = new Tile();
                }
            }
        }

        public List<Vector2> GetFreeMapPos(Direction a_dir)
        {
            List<Vector2> free = new List<Vector2>();

            if (a_dir == Direction.North || a_dir == Direction.South)
            {
                int y = 0;
                if (a_dir == Direction.South)
                {
                    y = HEIGHT - 1;
                }

                for (int x = 0; x < WIDTH; x++)
                {
                    if (m_tiles[x, y].m_tileType == Tile.TileType.Clear)
                    {
                        free.Add(new Vector2(x, y));
                    }
                }


            }
            else
            {
                int x = 0;
                if (a_dir == Direction.East)
                {
                    x = WIDTH - 1;
                }
                for (int y = 0; y < HEIGHT; y++)
                {
                    if (m_tiles[x, y].m_tileType == Tile.TileType.Clear)
                    {
                        free.Add(new Vector2(x, y));
                    }
                }

            }

            return free;
        }
    }
}
