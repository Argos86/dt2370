﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Tower_Defense.Model
{
    class Character
    {
        public int m_hitPoints = 0;
        public Vector2 m_pos;
        public Vector2 m_oldPos;

        public float m_timer = 0.0f;
        public List<Vector2> m_path;

        private AStar m_searcher;

        public bool IsAlive()
        {
            return m_hitPoints > 0;
        }

        public Character()
        {
            m_hitPoints = 0;
            m_pos = new Vector2(0, 0);
            m_oldPos = new Vector2(0, 0);
            m_timer = 0.0f;
            m_searcher = null;
        }

        public Character(Vector2 a_pos)
        {
            m_hitPoints = 10;
            m_pos = a_pos;
            m_oldPos = m_pos;
            m_timer = 0.0f;
            m_path = new List<Vector2>();
            m_searcher = null;
        }

        public bool Update(float a_elapsedTime)
        {
            m_timer -= a_elapsedTime;
            if (IsAlive() == false)
            {
                return false;
            }
            if (m_timer > 0)
            {
                return false;
            }

            return true;
        }

        public void FollowPath()
        {
            if (m_path.Count > 0)
            {
                m_oldPos = m_pos;
                m_pos = m_path.First();
                m_path.RemoveAt(0);
                m_timer = 0.5f;
            }
            else
            {
                m_oldPos = m_pos;
            }
        }
    }
}
